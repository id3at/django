from django.test import TestCase
import string
# Create your tests here.


print(100//7)