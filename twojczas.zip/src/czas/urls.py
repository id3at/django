from django.urls import include, path
from czas.views import KontaktModelView,get_name, sukces 
urlpatterns = [

    path('kontakt/', KontaktModelView.as_view()),
    path('', get_name,),
    path('sukces/', sukces,),



]
