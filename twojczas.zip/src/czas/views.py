
import random
from django.shortcuts import render
from .forms import KontaktmodelForm, CzasModelForm
from .cytaty import cytat
from .czaszycia import czaszycia
from django.views.generic import CreateView
from django.utils import timezone
from django import template

register = template.Library()


# Create your views here.


data = timezone.now
cytacik = cytat()
kolory = [random.randint(300000, 999999) for t in range(1, 100)]
dane = {"kolor": kolory, "cytat": cytacik, 'data': data}


class KontaktModelView(CreateView):
    template_name = 'kontakt.html'
    form_class = KontaktmodelForm
    success_url="/sukces/"

    def get_context_data(self, **kwargs,):
        context = super().get_context_data(**dane)
        context['cos'] = 'cos'

        return context



def get_name(request):
    # username = request.META['USERNAME']
    if request.method == 'POST':
        # if request.POST.get("czaszycia") == 'Oblicz czas życia':
        # create a form instance and populate it with data from the request:
        form = CzasModelForm(request.POST or None)
        slownik = request.POST
        data_for = slownik['data'].split('-')
        twojczas = czaszycia(IMIE=slownik['email'][0:slownik['email'].index('@')], ROK=int(
            data_for[0]), MIESIAC=int(data_for[1]), DZIEN=int(data_for[2])).splitlines()
        dane2 = {'form': form, "twojczas": twojczas,
                 "kolor": kolory, "cytat": cytacik, 'slownik': slownik,}
        # check whether it's valid:
        if form.is_valid():
            form.save()
            CzasModelForm()
            return render(request, 'czas_policzony.html', context=dane2)

    # if a GET (or any other method) we'll create a blank form
    else:
        form = CzasModelForm()
        dane2 = {'form': form, "kolor": kolory, "cytat": cytacik, "data": data }

    return render(request, 'czas.html', context=dane2)
   

def sukces(request):
    return  render(request, "sukces.html", dane)


