from django import forms
import string

class FormTextToLeetSpeak(forms.Form):
    tekst_to = forms.CharField(label="Tekst na leetspeak", required=False,widget=forms.Textarea(attrs={'placeholder': f'Wpisz tekst do tlumaczenia (Tylko litery alfabetu: {string.ascii_letters})', "rows": 5, 'class': 'form-control','id':"exampleFormControlTextarea4",}))

class FormLeetSpeakToText(forms.Form):
    leet = forms.CharField(label="Leetspeak na tekst",required=False, widget=forms.Textarea(attrs={'placeholder': 'Wpisz LeetSpeak do tlumaczenia', "rows": 5,'class': 'form-control','id':"exampleFormControlTextarea4", }))