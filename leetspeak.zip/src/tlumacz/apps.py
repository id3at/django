from django.apps import AppConfig


class TlumaczConfig(AppConfig):
    name = 'tlumacz'
