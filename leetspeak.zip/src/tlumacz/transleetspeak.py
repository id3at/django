import random
import string

def leetspeak(znaki):
    lista_zmienionych_znakow = []
    ogonki = {'ą': 'a', 'ć': 'c', 'ę':'e', 'ł':'l', 'ń': 'n', 'ó':'o','ś':'s','ź':'z','ż':'z','’':'' }
    suma = string.digits + string.punctuation
    znaki = "".join(filter(lambda x: x not in suma, znaki))
    
    for z in znaki:
        for znak in ogonki:
            if znak == z:
                znaki = znaki.replace(znak, ogonki[znak])
            
    alfabet = {'A': ['4', "@", "^",  "∂", ],
           "B": ["8",  "ß",],
           "C": ["[", "¢", "<", "(", "©"],
           "D": [")",  "?",],
           "E": ["3", "£", "€", "{",],
           "F": ['|"', 'ƒ',],
           "G": ['6', '&', ],
           "H": ['#', ],
           "I": ['!', '¡', ']'],
           "J": ['_|', '¿', '_['],
           "K": ['X', '|<', '|{', ']{', '|X'],
           "L": ['1_', '|', '|_', 'el', ],
           "M": ['|v|','em', ],
           "N": ['^/', '₪'],
           "O": ['0', 'oh', ],
           'P': ['|*',  '9', ],
           "Q": ['(_,)', '()', ],
           "R": ['|`', '®',  'Я', 'ſ'],
           "S": ['5', '$', 'z', '§',],
           "T": ['7', '+', '†',],
           "U": ['(_)','µ'],
           "V": ['\/', ],
           "W": ['\/\/', "vv", "Ш", "uu"],
           "X": ['><', 'Ж', '×', 'χ', ],
           "Y": ['j', 'Ч', 'γ'],
           "Z": ['2', 's']
           }

    for znak in znaki:
        if znak.upper() in alfabet:
            dlugosc = len(alfabet[znak.upper()])
            liczba_znakow = random.randrange(0, dlugosc)
            lista_zmienionych_znakow.append(alfabet[znak.upper()][liczba_znakow])
        else:
            lista_zmienionych_znakow.append(znak)

    tlumaczenie_znakow = ''.join( t for t in lista_zmienionych_znakow)

    return tlumaczenie_znakow



def transleetspeak(zdanie):
    alfabet = {'A': ['4', "@", "^",  "∂", ],
           "B": ["8",  "ß",],
           "C": ["[", "¢", "<", "(", "©"],
           "D": [")",  "?",],
           "E": ["3", "£", "€", "{",],
           "F": ['|"', 'ƒ',],
           "G": ['6', '&', ],
           "H": ['#', ],
           "I": ['!', '¡', ']'],
           "J": ['_|', '¿', '_['],
           "K": ['X', '|<', '|{', ']{', '|X'],
           "L": ['1_', '|', '|_', 'el', ],
           "M": ['|v|','em', ],
           "N": ['^/', '₪'],
           "O": ['0', 'oh', ],
           'P': ['|*',  '9', ],
           "Q": ['(_,)', '()', ],
           "R": ['|`', '®',  'Я', 'ſ'],
           "S": ['5', '$', 'z', '§',],
           "T": ['7', '+', '†'],
           "U": ['(_)','µ'],
           "V": ['\/', ],
           "W": ['\/\/', "vv", "Ш", "uu"],
           "X": ['><', 'Ж', '×', 'χ', ],
           "Y": ['j', 'Ч','γ'],
           "Z": ['2', 's']
           }
    tlumaczenie = []
    

    for slowo in zdanie.split(): #pobieranie slowa do tlumaczenie
        if tlumaczenie:
            tlumaczenie.append('_')
    
        liczba= 0
        while slowo:

        
        
            liczba = 0
          
   
                
                
            for _ in range(len(slowo)):
                      
                c = slowo[:len(slowo)- liczba]
                liczba += 1
        

        
                for litera_alfabetu in alfabet: #pobiertanie litery klucza w alfabecie
                    
                
                    if c== None:
                        continue            
                    if c in alfabet[litera_alfabetu]: #sprawdzanie czy slowo jest w wartosci slownika alfabetu
                        
                        tlumaczenie.append(litera_alfabetu)
                        
                        slowo = slowo.replace(c, "", 1)
                        liczba = 0
                    

                        break

                        
    tlumaczenie_str = "".join(tlumaczenie).replace("_", " ")

    return tlumaczenie_str.lower().title()
                    

