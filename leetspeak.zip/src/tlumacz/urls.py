from tlumacz.views import viewleetspeak 
from django.urls import path

urlpatterns = [
    path('', viewleetspeak),
]
