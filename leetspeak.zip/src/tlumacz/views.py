from django.shortcuts import render
from .forms import FormTextToLeetSpeak, FormLeetSpeakToText
from .transleetspeak import leetspeak, transleetspeak
from django.utils import timezone

# Create your views here.

data = timezone.now()
def viewleetspeak(request):
    form = FormTextToLeetSpeak()
    form2 = FormLeetSpeakToText()
    if request.method == 'POST':
        form = FormTextToLeetSpeak(request.POST or None)
        form2 = FormLeetSpeakToText(request.POST or None)
        
        if form.is_valid() :
            
            tekst_do_tlumaczenie = form.cleaned_data['tekst_to']
            przetlumaczony_tekst = leetspeak(tekst_do_tlumaczenie)
            
            
        if  form2.is_valid():
    
            leet_do_tlumaczenie = form2.cleaned_data['leet']
            przetlumaczony_leetspeak = transleetspeak(leet_do_tlumaczenie)
            

            return render(request, 'form.html', {'form2': form2,'form': form, 'przetlumaczony_leetspeak': przetlumaczony_leetspeak, 'przetlumaczony_tekst': przetlumaczony_tekst, 'data': data})
    return render(request, 'form.html', {'form': form,'form2': form2,'data': data })

