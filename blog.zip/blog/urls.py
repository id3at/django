from django.urls import include, path
from blog.views import BlogModelView, WpisModelView, KontaktModelView, home_view, get_name, portfolio_view

urlpatterns = [
    path('', home_view),
    path('blog/', BlogModelView.as_view()),
    path('blog/wpis/<int:pk>/', WpisModelView.as_view()),
    path('kontakt/', KontaktModelView.as_view()),
    path('czas/', get_name,),
    path('portfolio/', portfolio_view,),


]
