from bs4 import BeautifulSoup
import requests
import random

def cytat():

    dane = []
    source = requests.get("http://www.aforyzmy.com.pl/")
    src = source.content
    soup = BeautifulSoup(src, 'lxml-xml')

    for enume, znajdz in enumerate(soup.find_all(class_="widget-area")):
        if enume < 2:
            for enum, t in enumerate(znajdz.find_all("a")):
                dane.append(t.get("href"))
                # print(enum, t.get("href"))

    losowy_temat = random.choice(dane)

    # print(losowy_temat)

    liczba = [0]
    source_liczba_page = requests.get(f'{losowy_temat}')
    src_liczba_page = source_liczba_page.content
    soup_liczba_page = BeautifulSoup(src_liczba_page, 'lxml-xml')

    for znajdz in soup_liczba_page.find_all(class_="wp-paginate font-inherit"):
        for enum, znaj in enumerate(znajdz.find_all("a", class_="page")):
            if liczba[0] < int(znaj.get("title")):
                liczba[0] = int(znaj.get("title"))

    cytaty = []
    autor = []

    for pagina in range(0, liczba[0]):
        if pagina == 1:
            continue
        else:
            source1 = requests.get(f'{losowy_temat}/page/{pagina}')
            src1 = source1.content
            soup1 = BeautifulSoup(src1, 'lxml-xml')

            for znajdz in soup1.find_all(class_="entry-title"):
                for enum, znaj in enumerate(znajdz.find_all("a")):
                    # print(enum, znaj.text)
                    cytaty.append(znaj.text)
            for znajdz in soup1.find_all(class_="entry-content"):
                for enum, znaj in enumerate(znajdz.find_all("p")):
                    if znaj == None:
                        continue
                    else:
                        autor.append(znaj.text)

    autor = [t for t in autor if t != ""]
    # cytaciki = {a: b for (a, b) in (zip(cytaty, autor))}

    cytato = list((zip(cytaty, autor)))

    return cytato