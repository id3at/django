
import random
from django.shortcuts import render
from .models import BlogModel
from .forms import KontaktmodelForm, CzasModelForm
from .cytaty import cytat
from .czaszycia import czaszycia
from django.views.generic import ListView, DetailView, CreateView
import time


# Create your views here.



cytacik = cytat()
lista = czaszycia().splitlines()
kolory = [random.randint(300000, 999999) for t in range(1, 100)]
dane = {"czas_klucz": lista, "kolor": kolory, "cytat": cytacik,}



def home_view(request):
    return render(request, 'home_view.html', dane)

def portfolio_view(request):
    return render(request, 'portfolio_view.html', dane)



class BlogModelView(ListView):
    queryset = BlogModel.objects.all().order_by('-data_wpisu')
    paginate_by = 3
    template_name = 'blog.html'

    def get_context_data(self, **kwargs,):
        context = super().get_context_data(**dane)
        context['cos'] = 'cos'

        return context


class WpisModelView(DetailView,):
    queryset = BlogModel.objects.all().order_by('-data_wpisu')
    template_name = 'wpis.html'

    def get_context_data(self, **kwargs,):
        context = super().get_context_data(**dane)
        context['cos'] = 'cos'

        return context


class KontaktModelView(CreateView):
    template_name = 'kontakt.html'
    form_class = KontaktmodelForm

    def get_context_data(self, **kwargs,):
        context = super().get_context_data(**dane)
        context['cos'] = 'cos'

        return context


def get_name(request):
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = CzasModelForm(request.POST or None)

        slownik = request.POST

        twojczas = czaszycia(IMIE=slownik['email'][0:slownik['email'].index('@')], ROK=int(slownik['data_year']), MIESIAC=int(slownik['data_month']), DZIEN=int(slownik['data_day'])).splitlines()
        dane2 = {'form': form, "twojczas": twojczas, "czas_klucz": lista, "kolor": kolory, "cytat": cytacik, 'slownik': slownik}
        # check whether it's valid:
        if form.is_valid():
            form.save()
            CzasModelForm()

            return render(request, 'czas.html', context=dane2)

    # if a GET (or any other method) we'll create a blank form
    else:
        form = CzasModelForm()
        dane2 = {'form': form, "kolor": kolory, "cytat": cytacik, }

    return render(request, 'czas.html', context=dane2)
