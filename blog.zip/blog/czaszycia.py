import datetime
import locale


def czaszycia(IMIE="Pythom.pl", ROK=2020, MIESIAC=5, DZIEN=28):

    locale.setlocale(locale.LC_TIME, "pl_PL")
    AKTUALNYCZAS = datetime.datetime.today()
    DATANARODZIN = datetime.datetime(ROK, MIESIAC, DZIEN)
    urojony = datetime.datetime((AKTUALNYCZAS.year + 1), MIESIAC, DZIEN)
    Wiek = AKTUALNYCZAS.year - DATANARODZIN.year
    mies = AKTUALNYCZAS.month - DATANARODZIN.month
    kiedysto = 100 + DATANARODZIN.year
    Wiekdelta = AKTUALNYCZAS - DATANARODZIN
    sek = Wiekdelta.total_seconds()
    min = sek / 60
    godziny = min / 60
    przyszleur = urojony - AKTUALNYCZAS
    za_ile_dni_ur = przyszleur.days
    resztatygodni = (Wiekdelta.days - ((Wiekdelta.days // 7) * 7))

    if mies < 0:
        mies = 12 + int(mies)
        Wiek = int(AKTUALNYCZAS.year - DATANARODZIN.year) - 1
    if za_ile_dni_ur > 364:
        za_ile_dni_ur -= 364

    wiekmies = (Wiek) * 12 + (mies)

    if IMIE == "Pythom.pl":
        c = (f"""\n Witaj, jestem {IMIE} !! \n
        Jest: {AKTUALNYCZAS: %A, %d, %B, %Y}.
        Mam: {Wiek} lat i {mies} miesiące.
        Przeżyłem już {wiekmies:,} miesiecy
        a to jest {Wiekdelta.days // 7:,} tygodni i {resztatygodni} dni,
        czyli {Wiekdelta.days:,} dni,
        a to jest {int(godziny):,} godzin,
        a to jest {int(min):,} minut,
        a to jest {int(sek):,} sekund.
        100 lat osiągnę w roku:, {kiedysto}
        Urodziny obchodzę za {int(przyszleur.days)} dni ;)""")
    else:
        c = (f"""\n Witaj, {IMIE} !! \n
        Jest: {AKTUALNYCZAS: %A, %d, %B, %Y}.
        Masz: {Wiek} lat i {mies} miesiące.
        Przeżyłeś już {wiekmies:,} miesiecy
        a to jest {Wiekdelta.days // 7:,} tygodni i {resztatygodni} dni,
        czyli {Wiekdelta.days:,} dni,
        a to jest {int(godziny):,} godzin,
        a to jest {int(min):,} minut,
        a to jest {int(sek):,} sekund.
        100 lat osiągniesz w roku:, {kiedysto}
        Urodziny obchodzisz za {int(za_ile_dni_ur)} dni ;)""")
    return c
