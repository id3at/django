from django.contrib import admin
from .models import BlogModel, KontaktModel
from .models import CzasModel

# Register your models here.


class AdminBlogModel(admin.ModelAdmin):
    list_display = ('tytuł', 'artykuł', 'data_wpisu')


class AdminKontaktModel(admin.ModelAdmin):
    list_display = ('tytuł', 'email', 'data_wpisu')


class CzasModelAdmin(admin.ModelAdmin):
    list_display = ('email', 'data_dodania')
    search_fields = ('email', 'data_dodania')


admin.site.register(BlogModel, AdminBlogModel)
admin.site.register(KontaktModel, AdminKontaktModel)
admin.site.register(CzasModel, CzasModelAdmin)

# Register your models here.

