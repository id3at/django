from django.db import models

# Create your models here.


class BlogModel(models.Model):
    tytuł = models.CharField(max_length=200)
    artykuł = models.TextField()
    data_wpisu = models.DateTimeField(auto_now_add=True)


class KontaktModel(models.Model):
    tytuł = models.CharField(max_length=200)
    email = models.EmailField(unique=True)
    treść = models.TextField()
    data_wpisu = models.DateTimeField(auto_now_add=True)

    def get_absolute_url(self):
        return '/kontakt'


class CzasModel(models.Model):
    email = models.EmailField(unique=True)
    data = models.DateField()
    data_dodania = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.email
