from django import forms
from .models import KontaktModel
from .models import CzasModel


class KontaktmodelForm(forms.ModelForm):
    class Meta:
        model = KontaktModel
        fields = ['tytuł', 'email', 'treść',]
        widgets = {'email': forms.Textarea(attrs={'placeholder': 'Podaj Email.', 'class': 'kontakt', 'rows': 1}),
                   'tytuł': forms.Textarea(attrs={'placeholder': 'Podaj Tytuł.', 'class': 'kontakt', 'rows': 1}),
                   'treść': forms.Textarea(attrs={'placeholder': 'Napisz Wiadomość.', 'class': 'kontakt', })

                   }
        labels = {'email': (''), 'tytuł': (''), 'treść': (''), }
        # help_texts = {'email': ('Podaj Email.'), 'tytuł': ('Podaj Tytuł.'), 'treść': ('Napisz Wiadomość.'), }



lata = list(range(1890, 2021))

class CzasModelForm(forms.ModelForm):
    class Meta:
        model = CzasModel
        fields = ['email','data']
        widgets = {'data': forms.SelectDateWidget(years=lata,)}

